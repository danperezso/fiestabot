# 💘 FiestaMatch Bot

Bot de Telegram estilo Tinder para fiestas. Los asistentes crean su perfil, exploran el de los demás y si dos personas se dan like mutuamente → ¡Match! Solo entonces se muestra el teléfono.

---

## Puesta en marcha

### 1. Crear el bot en Telegram

1. Abre Telegram y busca **@BotFather**
2. Escribe `/newbot`
3. Elige un nombre (ej: `FiestaMatch`) y un usuario (ej: `fiestaXXXX_bot`)
4. BotFather te dará un **token** (parece `123456789:AAxxxx...`). Guárdalo.

### 2. Instalar dependencias

```bash
npm install
```

### 3. Configurar el token

Copia `.env.example` a `.env` y pega tu token:

```bash
cp .env.example .env
# Edita .env y pon tu token real
```

O expórtalo directamente:

```bash
export BOT_TOKEN=123456789:AAxxxxxxxxxxxxxxxx
```

### 4. Arrancar el bot

```bash
node bot.js
```

Deja esta terminal abierta (o usa `pm2` / un servidor para que corra 24h).

---

## Comandos del bot

| Comando | Qué hace |
|---|---|
| `/start` | Crear perfil o volver al menú |
| `/explorar` | Ver perfiles y dar likes |
| `/matches` | Ver tus matches con su contacto |
| `/miperfil` | Ver tu perfil actual |
| `/ayuda` | Lista de comandos |

---

## Flujo de uso en la fiesta

1. Comparte el link del bot: `https://t.me/NOMBRE_DEL_BOT`
2. Los asistentes abren el link y crean su perfil (nombre, edad, ciudad, gustos, descripción, Instagram y teléfono)
3. Exploran perfiles con los botones **❌ Pasar** / **💖 Me gusta**
4. Si dos personas se dan like mutuamente → ambas reciben una notificación de **¡MATCH!** con el contacto completo (Instagram + teléfono)

---

## Datos guardados

Los perfiles se guardan en `db.json` en la misma carpeta. No se necesita base de datos externa.

---

## Despliegue continuo (opcional)

Para que el bot corra aunque cierres la terminal:

```bash
npm install -g pm2
pm2 start bot.js --name fiestabot
pm2 save
```
